
local discordia = require('discordia')
local client = discordia.Client()
local prefix = 'vr!'

discordia.extensions()

local HTTP = require('coro-http')
local json = require('json')

client:on('ready', function()
    client:setGame("Countryballs: catch 'em all")
    print('bot is ready')
end)

client:on('messageCreate', function(message)
    if message.author == client.user then
        return
      end
      
    local country_coins = {}
    local countryballs = {
        {
          name = 'USA',
          image = 'usa.png',
          description = 'The United States of America is a federal republic consisting of 50 states and a capital district.'
        },
        {
          name = 'French Polynesia',
          image = 'french_polynesia.png',
          description = 'French Polynesia is an overseas collectivity of the French Republic located in the Pacific Ocean. It is composed of several groups of islands, the most famous of which are the Society Islands.'
        },
        {
          name = 'Germany',
          image = 'germany.png',
          description = 'Germany is a federal parliamentary republic located in central Europe. It is the most populous member state of the European Union.'
        },
        {
            name = 'Kuwait',
            image = 'kuwait.png',
            description = 'Kuwait is a country located in the northeastern region of the Arabian Peninsula. It is a constitutional emirate with a hereditary ruling family, the Al-Sabah, who have ruled since the 18th century.'
        },
        {
            name = 'Serbia',
            image = 'serbia.png',
            description = 'Serbia is a country located in Southeastern Europe. It is a parliamentary republic with a president as head of state and a prime minister as head of government.'
          },
          {
            name = 'Romania',
            image = 'romania.png',
            description = 'Romania is a country located in Southeastern Europe. It is a semi-presidential representative democratic republic with a president and a prime minister as heads of state and government.'
          },
          {
            name = 'Cocos Islands',
            image = 'cocos_islands.png',
            description = 'The Cocos Islands are a territory of Australia located in the Indian Ocean. They were formerly known as the Cocos-Keeling Islands.'
          },
          {
            name = 'China',
            image = 'china.png',
            description = 'China is a country located in East Asia. It is the world\'s most populous country and the second largest by land area. It is a socialist single-party state ruled by the Communist Party of China.'
          },
          {
            name = 'Taiwan',
            image = 'taiwan.png',
            description = 'Taiwan is a country located in East Asia. It is the most populous state and largest economy that is not a member of the United Nations. It is a multiparty democracy with a president and a premier as heads of state and government.'
          },
          {
            name = 'South Korea',
            image = 'south_korea.png',
            description = 'South Korea is a country located in East Asia. It is a presidential representative democratic republic with a president as head of state and a prime minister as head of government.'
          },
          {
            name = 'North Korea',
            image = 'north_korea.png',
            description = 'North Korea is a country located in East Asia. It is a single-party socialist state with a hereditary ruling family, the Kim family, and an official ideology of Juche.'
          },
          {
            name = 'Japanese Empire',
            image = 'japanese_empire.png',
            description = 'The Japanese Empire was a historical nation-state that existed from the Meiji Restoration in 1868 until the end of World War II in 1945. It was a constitutional monarchy with an emperor as head of state and a prime minister as head of government.'
          },
          {
            name = 'USSR',
            image = 'ussr.png',
            description = 'The Union of Soviet Socialist Republics (USSR) was a socialist state in Eastern Europe and northern Asia that existed from 1922 to 1991. It was a federal socialist state with a communist party-led government.'
          },
          {
            name = 'Russia',
            image = 'russia.png',
            description = 'Russia is a country located in Eastern Europe and northern Asia. It is the largest country in the world by land area and the eighth most populous. It is a federal semi-presidential republic with a president and a prime minister as heads of state and government.'
          },
          {
            name = 'UK',
            image = 'uk.png',
            description = 'The United Kingdom is a sovereign country located off the northwest coast of the European continent. It is a constitutional monarchy with a parliamentary system of government and a queen as head of state.'
          },
          {
            name = 'Australia',
            image = 'australia.png',
            description = 'Australia is a country located in the southern hemisphere. It is the world\'s sixth-largest country by land area. It is a parliamentary democracy with a governor-general as head of state and a prime minister as head of government.'
          },
          {
            name = 'Cook Islands',
            image = 'cook_islands.png',
            description = 'The Cook Islands are a self-governing parliamentary democracy in free association with New Zealand. They are located in the South Pacific Ocean.'
          },
          {
            name = 'Maldives',
            image = 'maldives.png',
            description = 'The Maldives is a country located in South Asia. It is an archipelago of 26 coral atolls in the Indian Ocean. It is a presidential representative democratic republic with a president as head of state and a prime minister as head of government.'
          },
          {
            name = 'Tonga',
            image = 'tonga.png',
            description = 'Tonga is a country located in the Pacific Ocean. It is an archipelago of 169 islands. It is a constitutional monarchy with a king as head of state and a prime minister as head of government.'
          },
          {
            name = 'Tunisia',
            image = 'tunisia.png',
            description = 'Tunisia is a country located in North Africa. It is a unitary presidential representative democratic republic with a president as head of state and a prime minister as head of government.'
          },
          {
            name = 'Algeria',
            image = 'algeria.png',
            description = 'Algeria is a country located in North Africa. It is a semi-presidential republic with a president as head of state and a prime minister as head of government.'
          },
          {
            name = 'Anguilla',
            image = 'anguilla.png',
            description = 'Anguilla is a British Overseas Territory located in the Caribbean Sea. It is a parliamentary representative democratic dependency with a chief minister as head of government.'
          },
          {
            name = 'Armenia',
            image = 'armenia.png',
            description = 'Armenia is a country located in Western Asia. It is a unitary parliamentary democratic republic with a president as head of state and a prime minister as head of government.'
          },
          {
            name = 'Austria',
            image = 'austria.png',
            description = 'Austria is a country located in Central Europe. It is a federal parliamentary republic with a president as head of state and a chancellor as head of government.'
          },
          {
            name = 'Bahrain',
            image = 'bahrain.png',
            description = 'Bahrain is a country located in the Persian Gulf. It is an island nation. It is a constitutional monarchy with a king as head of state and a prime minister as head of government.'
          },
          {
            name = 'Benin',
            image = 'benin.png',
            description = 'Benin is a country located in West Africa. It is a presidential representative democratic republic with a president as head of state and a prime minister as head of government.'
          },
          {
            name = 'Bhutan',
            image = 'bhutan.png',
            description = 'Bhutan is a country located in South Asia. It is a unitary parliamentary democracy with a constitutional monarchy. The king is the head of state and the prime minister is the head of government.'
          },
          {
            name = 'Cameroon',
            image = 'cameroon.png',
            description = 'Cameroon is a country located in Central and West Africa. It is a presidential republic with a president as head of state and a prime minister as head of government.'
          },
          {
            name = 'Chad',
            image = 'chad.png',
            description = 'Chad is a country located in North Africa. It is a presidential representative democratic republic with a president as head of state and a prime minister as head of government.'
          },
          {
            name = 'China',
            image = 'china.png',
            description = 'China is a country located in East Asia. It is the world\'s most populous country and the second largest by land area. It is a socialist single-party state ruled by the Communist Party of China.'
          },
          {
            name = 'Colombia',
            image = 'colombia.png',
            description = 'Colombia is a country located in South America. It is a presidential representative democratic republic with a president as head of state and a prime minister as head of government.'
          },
          {
            name = 'CSA',
            image = 'csa.png',
            description = 'The Confederate States of America (CSA) was a country that existed from 1861 to 1865. It was a federal presidential representative democratic republic with a president as head of state and a prime minister as head of government.'
          },
          {
            name = 'Cuba',
            image = 'cuba.png',
            description = 'Cuba is a country located in the Caribbean Sea. It is a unitary socialist state with a president as head of state and a prime minister as head of government.'
          },
          {
            name = 'Curacao',
            image = 'curacao.png',
            description = 'Curaçao is a country located in the Caribbean Sea. It is an autonomous country within the Kingdom of the Netherlands. It has a parliamentary representative democratic system of government with a prime minister as head of government.'
          },
          {
            name = 'Democratic Republic of Sao Tome and Príncipe',
            image = 'sao_tome_and_principe.png',
            description = 'The Democratic Republic of São Tomé and Príncipe is a country located in Central Africa. It is a presidential representative democratic republic with a president as head of state and a prime minister as head of government.'
          },
          {
            name = 'Easter Island',
            image = 'easter_island.png',
            description = 'Easter Island is a territory of Chile located in the Pacific Ocean. It is a special territory with a governor as head of government.'
          },
          {
            name = 'Egypt',
            image = 'egypt.png',
            description = 'Egypt is a country located in North Africa. It is a presidential representative democratic republic with a president as head of state and a prime minister as head of government.'
          },
          {
            name = 'European Union',
            image = 'european_union.png',
            description = 'The European Union (EU) is a political and economic union of 27 European countries. It is a supranational union with a president as head of state and a prime minister as head of government.'
          },
          {
            name = 'Fiji',
            image = 'fiji.png',
            description = 'Fiji is a country located in the Pacific Ocean. It is an archipelago of 333 islands. It is a parliamentary representative democratic republic with a president as head of state and a prime minister as head of government.'
          },
          {
            name = 'France',
            image = 'france.png',
            description = 'France is a country located in Western Europe. It is a unitary semi-presidential democratic republic with a president as head of state and a prime minister as head of government.'
          },
          {
            name = 'Georgia',
            image = 'georgia.png',
            description = 'Georgia is a country located in the Caucasus region of Eurasia. It is a unitary parliamentary democratic republic with a president as head of state and a prime minister as head of government.'
          },
          {
            name = 'Greece',
            image = 'greece.png',
            description = 'Greece is a country located in Southeast Europe. It is a parliamentary republic with a president as head of state and a prime minister as head of government.'
          },
          {
            name = 'Greenland',
            image = 'greenland.png',
            description = 'Greenland is a country located in North America. It is an autonomous country within the Kingdom of Denmark. It has a parliamentary representative democratic system of government with a prime minister as head of government.'
          },
          {
            name = 'HIMI',
            image = 'himi',
            description = 'The Heard Island and McDonald Islands are a territory of Australia located in the Indian Ocean. It is a non-self-governing territory with an administrator as head of government.'
          },
          {
            name = 'Jersey',
            image = 'jersey.png',
            description = 'Jersey is a British Crown Dependency located in the English Channel. It is a parliamentary representative democratic system of government with a chief minister as head of government.'
          },
          {
            name = 'Korea',
            image = 'korea.png',
            description = 'Korea is a peninsula located in East Asia. It is divided into two countries: the Democratic People`s Republic of Korea (North Korea) and the Republic of Korea (South Korea). Both countries have different systems of government.'
          },
          {
          name = 'Malta',
          image = 'malta.png',
          description = 'Malta is a country located in the Mediterranean Sea. It is a parliamentary republic with a president as head of state and a prime minister as head of government.'
         },
         {
            name = 'Mauritania',
            image = 'mauritania.png',
            description = 'Mauritania is a country located in West Africa. It is an Islamic presidential representative democratic republic with a president as head of state and a prime minister as head of government.'
          },
          {
            name = 'Mexico',
            image = 'mexico.png',
            description = 'Mexico is a country located in North America. It is a federal presidential representative democratic republic with a president as head of state and a prime minister as head of government.'
          },
          {
            name = 'New Zealand',
            image = 'new_zealand.png',
            description = 'New Zealand is a country located in the Pacific Ocean. It is a parliamentary representative democratic monarchy with a governor general as head of state and a prime minister as head of government.'
          },
          {
            name = 'North Korea',
            image = 'north_korea.png',
            description = 'North Korea is a country located in East Asia. It is a socialist single-party state ruled by the Korean Workers` Party. It has a president as head of state and a prime minister as head of government.'
          },
          {
            name = 'Niue',
            image = 'niue.png',
            description = 'Niue is a country located in the Pacific Ocean. It is a self-governing territory in free association with New Zealand. It has a premier as head of government.'
          },
          {
            name = 'Ottoman Empire',
            image = 'ottoman_empire.png',
            description = 'The Ottoman Empire was a country that existed from 1299 to 1923. It was a federal presidential representative democratic republic with a president as head of state and a prime minister as head of government.'
          },
          {
            name = 'Paraguay',
            image = 'paraguay.png',
            description = 'Paraguay is a country located in South America. It is a presidential representative democratic republic with a president as head of state and a prime minister as head of government.'
          },
          {
            name = 'Saudi Arabia',
            image = 'saudi_arabia.png',
            description = 'Saudi Arabia is a country located in the Middle East. It is an absolute monarchy with a king as head of state and a prime minister as head of government.'
          },
          {
            name = 'Poland',
            image = 'poland.png',
            description = 'Poland is a country located in Central Europe. It is a unitary parliamentary democratic republic with a president as head of state and a prime minister as head of government.'
          },
          {
            name = 'Scotland',
            image = 'scotland.png',
            description = 'Scotland is a country located in the United Kingdom. It is a semi-autonomous country within the UK with a parliamentary representative democratic system of government with a first minister as head of government.'
          },
          {
            name = 'South Korea',
            image = 'south_korea.png',
            description = 'South Korea is a country located in East Asia. It is a presidential representative democratic republic with a president as head of state and a prime minister as head of government.'
          },
          {
            name = 'Senegal',
            image = 'senegal.png',
            description = 'Senegal is a country located in West Africa. It is a presidential representative democratic republic with a president as head of state and a prime minister as head of government.'
          },
          {
            name = 'Suriname',
            image = 'suriname.png',
            description = 'Suriname is a country located in South America. It is a unitary parliamentary democratic republic with a president as head of state and a prime minister as head of government.'
          },
          {
            name = 'Barbados',
            image = 'barbados.png',
            description = 'Barbados is a country located in the Caribbean Sea. It is a parliamentary representative democratic monarchy with a governor general as head of state and a prime minister as head of government.'
          },
          {
            name = 'Turk Islands',
            image = 'turk_islands.png',
            description = 'The Turk Islands are a territory of the United Kingdom located in the Caribbean Sea. It is a non-self-governing territory with an administrator as head of government.'
          },
          {
            name = 'Uruguay',
            image = 'uruguay.png',
            description = 'Uruguay is a country located in South America. It is a presidential representative democratic republic with a president as head of state and a prime minister as head of government.'
          },
          {
            name = 'Wales',
            image = 'wales.png',
            description = 'Wales is a country located in the United Kingdom. It is a semi-autonomous country within the UK with a parliamentary representative democratic system of government with a first minister as head of government.'
          },
          {
            name = 'Liechtenstein',
            image = 'liechtenstein.png',
            description = 'Liechtenstein is a small, alpine country located in central Europe. It is a parliamentary representative democratic monarchy, with a prince as head of state and a prime minister as head of government. It is known for its beautiful mountain scenery, small size, and strong economy.'
          },
          {
            name = 'Turkey',
            image = 'turkey.png',
            description = 'Turkey is a country located in both Europe and Asia. It is a presidential representative democratic republic, with a president as head of state and head of government. It is known for its rich cultural heritage, ancient history, and diverse geography, ranging from Mediterranean beaches to eastern steppes.'
          },
          {
            name = 'Switzerland',
            image = 'switzerland.png',
            description = 'Switzerland is a small, landlocked country located in central Europe. It is a federal parliamentary democratic republic, with a president as head of state and a council of seven members as head of government. It is known for its stunning alpine landscape, high quality of life, and political neutrality.'
          },
          {
            name = 'Canada',
            image = 'canada.png',
            description = 'Canada is a country located in North America. It is a federal parliamentary democratic monarchy, with a queen as head of state and a prime minister as head of government. It is known for its vast size, beautiful natural landscapes, and cultural diversity, with both English and French as official languages.'
          },
          {
            name = 'Portugal',
            image = 'portugal.png',
            description = 'Portugal is a country located in southwestern Europe. It is a parliamentary republic, with a president as head of state and a prime minister as head of government. It is known for its beautiful Atlantic coastline, rich cultural heritage, and delicious cuisine, including its famous wines and pastries.'
          },
          {
            name = 'Slovakia',
            image = 'slovakia.png',
            description = 'Slovakia is a country located in central Europe. It is a parliamentary republic, with a president as head of state and a prime minister as head of government. It is known for its stunning mountain scenery, rich cultural history, and strong economy.'
          },
          {
            name = 'Burkina Faso',
            image = 'burika_faso.png',
            description = 'Burkina Faso is a landlocked country located in West Africa. It is a semi-presidential representative democratic republic, with a president as head of state and a prime minister as head of government. It is known for its rich cultural traditions, diverse landscape, and friendly people.'
          },
          {
            name = 'USMOI',
            image = 'usmoi.png',
            description = 'The United States Minor Outlying Islands are a group of nine territories belonging to the United States, including Baker Island, Howland Island, Jarvis Island, Johnston Atoll, Kingman Reef, Midway Atoll, Navassa Island, Palmyra Atoll, and Wake Island. They are located in the Pacific and Indian Oceans, and are largely uninhabited except for a small number of staff and researchers. The islands are under the jurisdiction of the U.S. federal government, with most of them managed by the U.S. Fish and Wildlife Service as national wildlife refuges.'
          },
          {
            name = 'Italy',
            image = 'italy.png',
            description = 'Italy is a country located in Southern Europe known for its rich history, art, architecture, cultural heritage, delicious cuisine, fashion and luxury goods, famous museums and art galleries, beautiful countryside and landmarks such as the Colosseum, Leaning Tower of Pisa and Trevi Fountain.'
          },
          {
            name = 'Qing Dynasty',
            image = 'qing.png',
            description = 'The Qing Dynasty was the final imperial dynasty in China, lasting from 1644 to 1912. It was an era noted for its initial prosperity and tumultuous final years, and for being only the second time that China was not ruled by the Han people.'
          },
          {
            name = 'Indonesia',
            image = 'indonesia.png',
            description = 'Indonesia is a sovereign island country in Southeast Asia, located between the Indian and Pacific oceans. It is the world`s largest island country, with more than 17,000 islands. Indonesia is known for its diverse culture, with over 300 ethnic groups and more than 700 languages spoken. It is also known for its beautiful beaches, tropical rainforests, and rich biodiversity. The country is also home to many active volcanoes and has a diverse population with various religious and ethnic groups.'
          },
          {
            name = 'Monaco',
            image = 'monaco.png',
            description = 'Monaco is a small, independent city-state located on the French Riviera in Western Europe. It is bordered by France on three sides and has a Mediterranean coastline. Monaco is known for its luxurious lifestyle, glamorous events, and famous residents such as the royal family and wealthy businesspeople. It is also a popular tourist destination, known for its casinos, yachting, and high-end shopping.'
          },
      }
        local list = {
            'kuwait' ,
            'china',
            'jersey',
            'mauritania',
            'uruguay',
            'senegal' ,
            'haiti' ,
            'korea' ,
            'armenia' ,
            'paraguay' ,
            'cuba' ,
            'algeria' ,
            'wales' ,
            'france' ,
            'fiji' ,
            'uk',
            'usa' ,
            'serbia' ,
            'romania' ,
            'sao tome and principe', --'são tomé and príncipe' or 
            'countryballs',
            'chad',
            'suriname' ,
            'austria' ,
            'germany' ,
            'french polynesia' ,
            'russia' ,
            'taiwan' ,
            'europe' ,
            'maldives' , 
            'japanese empire' ,
            'bhutan',
            'nazi germany',
            'ussr',
            'csa',
            'easter island',
            'south korea',
            'north korea',
            'scotland',
            'cameroon',
            'bahrain',
            'tunisia',
            'georgia',
            'egypt',
            'benin',
            'bosnia',
            'tonga',
            'mexico',
            'niue',
            'colombia',
            'greenland',
            'malta',
            'heard island and mcdonald islands', --or 'himi',
            'democratic kampuchea',
            'thailand',
            'brazil',
            'cambodia',
            'wallis',
            'mayotte',
            'poland',
            'bangladesh',
            'saudi arabia',
            'new zealand',
            'curacao',
            'australia',
            'cook islands',
            'turk islands',
            'cocos islands',
            'anguilla',
            'greece',
            'ottoman empire',
            'barbados',
        }

        local cmd, args = string.match(message.content, "(%S+) (.*)")
        cmd = cmd or message.content
    
        local operators = {
            ["+"] = function(x,y) return x+y end,
            ["-"] = function(x,y) return x-y end,
            ["*"] = function(x,y) return x*y end,
            ["/"] = function(x,y) return x/y end
        }
    
        local completion = {}
        local countryball_images = countryballs[math.random(#countryballs)]
        
        if message.content:lower() == prefix.."spawn" then
            completion[message.author.id] = completion[message.author.id] or {}
            table.insert(completion[message.author.id], countryball_images.name)
            message.channel:send('`A Wild Countryball Appears!`')

            message.channel:send{
                file = 'images/countryballs/' .. countryball_images.image,
                name = countryball_images.name .. '.png'
              }

            message.channel:send('`Type your answer in the format:` vr!answer [country name]')
            client:on('messageCreate', function(guess)
                if guess.content:lower() == prefix..'answer '..countryball_images.name:lower() then
                    completion[guess.author.id] = completion[guess.author.id] or {}
                    table.insert(completion[guess.author.id], countryball_images.name)
                  guess:reply('Correct! You have caught ' .. countryball_images.name .. ' countryball.')
                end
              end)
            elseif message.content:lower() == prefix..'completion' then
                local caught = completion[message.author.id] or {}
                local caughtString = table.concat(caught, ', ')
                message.channel:send('You have caught: ' .. caughtString)
            elseif message.content:lower() == prefix..'description' then
              message.channel:send('images/icon/' .. countryball_images.image)
                message.channel:send(countryball_images.description)
        end

        if message.content == prefix..'ping' then
            message.channel:send('pong!')
        end

        if message.content == prefix..'credits' then
            message.channel:send('Credits to PolandDev, his team and CopiluCuSarmale')
        end
end)
local TokenString = io.open("token.txt", "r"):read('*a')
client:run('Bot '..TokenString)